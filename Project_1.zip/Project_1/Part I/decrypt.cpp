//Monir Hossen
#include<iostream>
using namespace std;
int main()
{

int k,digits,first,second,third,fourth,fifth;

  cout <<"Enter key value k: ";
  cin>>k;
  cout <<"Enter a 5-digit integer to decrypt: ";
  cin>>digits;
  fifth= digits %10;
  fourth=digits %100/10;
  third=digits%1000/100;
  second=digits%10000/1000;
  first=digits%100000/10000;

  first=first-k;
  second=second-k;
  third=third-k;
  fourth=fourth-k;
  fifth=fifth-k;

  if (first <0)
  first=first+10;
  else if (second <0)
  second=second+10;
  else if (third<0)
  third=third+10;
  else if (fourth<0)
  fourth=fourth+10;
  else if (fifth<0)
  fifth=fifth+10;

  cout <<"Decrypted value: "<<first<<second<<third<<fourth<<fifth<<endl;














  return 0;
}
