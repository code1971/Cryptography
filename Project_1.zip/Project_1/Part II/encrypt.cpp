//Monir Hossen
#include<iostream>
#include<cmath>

using namespace std;
int main()
{

long number;
int block_size, k;

cout <<"Enter a 16-digit integer to encrypt: ";
cin>>number;


int sixteenth= number%10;
int fifteenth= number%100/10;
int fourteenth= number%1000/100;
int thirteenth= number%10000/1000;
int twelvfth= number%100000/10000;
int eleventh= number%1000000/100000;
int tenth= number%10000000/1000000;
int ninth= number%100000000/10000000;
int eight= number%1000000000/100000000;
int seventh= number%10000000000/1000000000;
int sixth= number%100000000000/10000000000;
int fifth= number %1000000000000/100000000000;
int fourth= number%10000000000000/1000000000000;
int third= number% 100000000000000/10000000000000;
int second= number%1000000000000000/100000000000000;
int first= number% 10000000000000000/1000000000000000;
cout <<sixteenth <<endl;

cout <<"Enter a block size (possible values: 2, 4, 8, 16): ";
cin>>block_size;


cout <<"Enter k value: ";
cin>>k;

first+=k;
second+=k;
third+=k;
fourth+=k;
fifth+=k;
sixth+=k;
seventh+=k;
eight+=k;
ninth+=k;
tenth+=k;
eleventh+=k;
twelvfth+=k;
thirteenth+=k;
fourteenth+=k;
fifteenth+=k;
sixteenth+=k;

//I write this program for a block_size= 4;  depending on different block_size
//we can swap differently and get our Encrypted number. Thanks.

if (block_size==4){

  if (first >=10)
  first=(first%10);
  if (second >=10)
  second=(second%10);
  if (third>=10)
  third=(third%10);
  if (fourth>=10)
  fourth=(fourth%10);
  if (fifth>=10)
  fifth=(fifth%10);
  if (sixth>=10)
  sixth=(sixth%10);
  if (seventh>=10)
  seventh=(seventh%10);
  if (eight>=10)
  eight=(eight%10);
  if (ninth>=10)
  ninth=(ninth%10);
  if (tenth>=10)
  tenth=(tenth%10);
  if (eleventh>=10)
  eleventh=(eleventh%10);
  if (twelvfth>=10)
  twelvfth=(twelvfth%10);
  if (thirteenth>=10)
  thirteenth=(thirteenth%10);
  if (fourteenth>=10)
  fourteenth=(fourteenth%10);
  if (fifteenth>=10)
  fifteenth=(fifteenth%10);
  if (sixteenth>=10)
  sixteenth=(sixteenth%10);

  swap(first, third); swap(second, fourth);
  swap(fifth, seventh); swap(sixth, eight);
  swap(ninth, eleventh); swap(tenth, twelvfth);
  swap(thirteenth, fifteenth); swap(fourteenth, sixteenth);

}

if (block_size==8){

  if (first >=10)
  first=(first%10);
  if (second >=10)
  second=(second%10);
  if (third>=10)
  third=(third%10);
  if (fourth>=10)
  fourth=(fourth%10);
  if (fifth>=10)
  fifth=(fifth%10);
  if (sixth>=10)
  sixth=(sixth%10);
  if (seventh>=10)
  seventh=(seventh%10);
  if (eight>=10)
  eight=(eight%10);
  if (ninth>=10)
  ninth=(ninth%10);
  if (tenth>=10)
  tenth=(tenth%10);
  if (eleventh>=10)
  eleventh=(eleventh%10);
  if (twelvfth>=10)
  twelvfth=(twelvfth%10);
  if (thirteenth>=10)
  thirteenth=(thirteenth%10);
  if (fourteenth>=10)
  fourteenth=(fourteenth%10);
  if (fifteenth>=10)
  fifteenth=(fifteenth%10);
  if (sixteenth>=10)
  sixteenth=(sixteenth%10);

swap(first, eight); swap(second, seventh);
swap(third, sixth); swap(fourth,fifth);

swap(ninth, sixteenth); swap(tenth, fifteenth);
swap(eleventh, fourteenth); swap(twelvfth, thirteenth);

}


if (block_size==16){

  if (first >=10)
  first=(first%10);
  if (second >=10)
  second=(second%10);
  if (third>=10)
  third=(third%10);
  if (fourth>=10)
  fourth=(fourth%10);
  if (fifth>=10)
  fifth=(fifth%10);
  if (sixth>=10)
  sixth=(sixth%10);
  if (seventh>=10)
  seventh=(seventh%10);
  if (eight>=10)
  eight=(eight%10);
  if (ninth>=10)
  ninth=(ninth%10);
  if (tenth>=10)
  tenth=(tenth%10);
  if (eleventh>=10)
  eleventh=(eleventh%10);
  if (twelvfth>=10)
  twelvfth=(twelvfth%10);
  if (thirteenth>=10)
  thirteenth=(thirteenth%10);
  if (fourteenth>=10)
  fourteenth=(fourteenth%10);
  if (fifteenth>=10)
  fifteenth=(fifteenth%10);
  if (sixteenth>=10)
  sixteenth=(sixteenth%10);

  swap(first, ninth); swap(second, tenth);
  swap(third, eleventh); swap(fourth, twelvfth);
  swap(fifth, thirteenth); swap(sixth, fourteenth);
  swap(seventh, fifteenth); swap(eight, sixteenth);
}


if (block_size==2){

  if (first >=10)
  first=(first%10);
  if (second >=10)
  second=(second%10);
  if (third>=10)
  third=(third%10);
  if (fourth>=10)
  fourth=(fourth%10);
  if (fifth>=10)
  fifth=(fifth%10);
  if (sixth>=10)
  sixth=(sixth%10);
  if (seventh>=10)
  seventh=(seventh%10);
  if (eight>=10)
  eight=(eight%10);
  if (ninth>=10)
  ninth=(ninth%10);
  if (tenth>=10)
  tenth=(tenth%10);
  if (eleventh>=10)
  eleventh=(eleventh%10);
  if (twelvfth>=10)
  twelvfth=(twelvfth%10);
  if (thirteenth>=10)
  thirteenth=(thirteenth%10);
  if (fourteenth>=10)
  fourteenth=(fourteenth%10);
  if (fifteenth>=10)
  fifteenth=(fifteenth%10);
  if (sixteenth>=10)
  sixteenth=(sixteenth%10);

  swap(first, second); swap(third, fourth);
  swap(fifth, sixth); swap(seventh, eight);
  swap(ninth, tenth); swap(eleventh, twelvfth);
  swap(thirteenth, fourteenth); swap(fifteenth, sixteenth);
}







cout <<"Encrypted number is "<<first<<second<<third<<fourth<<fifth<<sixth
<<seventh<<eight<<ninth<<tenth<<eleventh<<twelvfth<<thirteenth
<<fourteenth<<fifteenth<<sixteenth<<"."<<endl;





  return 0;
}
