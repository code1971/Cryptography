//Monir Hossen
#include<iostream>
#include<cmath>

using namespace std;
int main()
{

long number;
int block_size, k;

cout <<"Enter a 16-digit integer to decrypt: ";
cin>>number;


int sixteenth= number%10;
int fifteenth= number%100/10;
int fourteenth= number%1000/100;
int thirteenth= number%10000/1000;
int twelvfth= number%100000/10000;
int eleventh= number%1000000/100000;
int tenth= number%10000000/1000000;
int ninth= number%100000000/10000000;
int eight= number%1000000000/100000000;
int seventh= number%10000000000/1000000000;
int sixth= number%100000000000/10000000000;
int fifth= number %1000000000000/100000000000;
int fourth= number%10000000000000/1000000000000;
int third= number% 100000000000000/10000000000000;
int second= number%1000000000000000/100000000000000;
int first= number% 10000000000000000/1000000000000000;
cout <<sixteenth <<endl;

cout <<"Enter a block size (possible values: 2, 4, 8, 16): ";
cin>>block_size;


cout <<"Enter k value: ";
cin>>k;

first-=k;
second-=k;
third-=k;
fourth-=k;
fifth-=k;
sixth-=k;
seventh-=k;
eight-=k;
ninth-=k;
tenth-=k;
eleventh-=k;
twelvfth-=k;
thirteenth-=k;
fourteenth-=k;
fifteenth-=k;
sixteenth-=k;



if (block_size==4){

  if (first <0)
  first=(first+10);
  if (second <0)
  second=(second+10);
  if (third<0)
  third=(third+10);
  if (fourth<0)
  fourth=(fourth+10);
  if (fifth<0)
  fifth=(fifth+10);
  if (sixth<0)
  sixth=(sixth+10);
  if (seventh<0)
  seventh=(seventh+10);
  if (eight<0)
  eight=(eight+10);
  if (ninth<0)
  ninth=(ninth+10);
  if (tenth<0)
  tenth=(tenth+10);
  if (eleventh<0)
  eleventh=(eleventh+10);
  if (twelvfth<0)
  twelvfth=(twelvfth+10);
  if (thirteenth<0)
  thirteenth=(thirteenth+10);
  if (fourteenth<0)
  fourteenth=(fourteenth+10);
  if (fifteenth<0)
  fifteenth=(fifteenth+10);
  if (sixteenth<0)
  sixteenth=(sixteenth+10);

  swap(third, first); swap(fourth, second);
  swap(seventh,fifth); swap(eight,sixth );
  swap(eleventh, ninth ); swap(twelvfth, tenth );
  swap(fifteenth,thirteenth ); swap(sixteenth, fourteenth);

}

if (block_size==8){


  if (first <0)
  first=(first+10);
  if (second <0)
  second=(second+10);
  if (third<0)
  third=(third+10);
  if (fourth<0)
  fourth=(fourth+10);
  if (fifth<0)
  fifth=(fifth+10);
  if (sixth<0)
  sixth=(sixth+10);
  if (seventh<0)
  seventh=(seventh+10);
  if (eight<0)
  eight=(eight+10);
  if (ninth<0)
  ninth=(ninth+10);
  if (tenth<0)
  tenth=(tenth+10);
  if (eleventh<0)
  eleventh=(eleventh+10);
  if (twelvfth<0)
  twelvfth=(twelvfth+10);
  if (thirteenth<0)
  thirteenth=(thirteenth+10);
  if (fourteenth<0)
  fourteenth=(fourteenth+10);
  if (fifteenth<0)
  fifteenth=(fifteenth+10);
  if (sixteenth<0)
  sixteenth=(sixteenth+10);

swap(eight, first); swap(seventh, second);
swap(sixth, third ); swap(fifth, fourth);

swap(sixteenth, ninth); swap(fifteenth, tenth);
swap(fourteenth, eleventh); swap(thirteenth, twelvfth);

}


if (block_size==16){

  if (first <0)
  first=(first+10);
  if (second <0)
  second=(second+10);
  if (third<0)
  third=(third+10);
  if (fourth<0)
  fourth=(fourth+10);
  if (fifth<0)
  fifth=(fifth+10);
  if (sixth<0)
  sixth=(sixth+10);
  if (seventh<0)
  seventh=(seventh+10);
  if (eight<0)
  eight=(eight+10);
  if (ninth<0)
  ninth=(ninth+10);
  if (tenth<0)
  tenth=(tenth+10);
  if (eleventh<0)
  eleventh=(eleventh+10);
  if (twelvfth<0)
  twelvfth=(twelvfth+10);
  if (thirteenth<0)
  thirteenth=(thirteenth+10);
  if (fourteenth<0)
  fourteenth=(fourteenth+10);
  if (fifteenth<0)
  fifteenth=(fifteenth+10);
  if (sixteenth<0)
  sixteenth=(sixteenth+10);

  swap(ninth,first); swap(tenth, second );
  swap(eleventh, third); swap(twelvfth, fourth);
  swap(thirteenth, fifth); swap(fourteenth, sixth);
  swap(fifteenth, seventh); swap(sixteenth, eight);
}


if (block_size==2){
  if (first <0)
  first=(first+10);
  if (second <0)
  second=(second+10);
  if (third<0)
  third=(third+10);
  if (fourth<0)
  fourth=(fourth+10);
  if (fifth<0)
  fifth=(fifth+10);
  if (sixth<0)
  sixth=(sixth+10);
  if (seventh<0)
  seventh=(seventh+10);
  if (eight<0)
  eight=(eight+10);
  if (ninth<0)
  ninth=(ninth+10);
  if (tenth<0)
  tenth=(tenth+10);
  if (eleventh<0)
  eleventh=(eleventh+10);
  if (twelvfth<0)
  twelvfth=(twelvfth+10);
  if (thirteenth<0)
  thirteenth=(thirteenth+10);
  if (fourteenth<0)
  fourteenth=(fourteenth+10);
  if (fifteenth<0)
  fifteenth=(fifteenth+10);
  if (sixteenth<0)
  sixteenth=(sixteenth+10);

  swap(second, first); swap(fourth, third);
  swap(sixth, fifth); swap(eight, seventh);
  swap(tenth, ninth); swap(twelvfth, eleventh);
  swap(fourteenth, thirteenth); swap(sixteenth, fifteenth);
}







cout <<"Encrypted number is "<<first<<second<<third<<fourth<<fifth<<sixth
<<seventh<<eight<<ninth<<tenth<<eleventh<<twelvfth<<thirteenth
<<fourteenth<<fifteenth<<sixteenth<<"."<<endl;





  return 0;
}
